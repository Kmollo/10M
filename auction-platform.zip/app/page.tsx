import Link from "next/link"
import { Clock, Upload, Award, ArrowRight, Moon } from "lucide-react"

import { Button } from "@/components/ui/button"
import AuctionCard from "@/components/auction-card"
import CategoryCard from "@/components/category-card"

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative flex flex-col items-center justify-center px-4 py-24 md:py-32 text-center">
        <h1 className="text-7xl md:text-9xl font-bold tracking-tighter mb-4">10M</h1>
        <p className="text-lg md:text-xl text-gray-300 max-w-md mb-8">
          The world's first 10-minute auction platform. Bid fast, win big.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button size="lg" className="bg-white text-black hover:bg-gray-200">
            Explore Live Auctions
          </Button>
          <Button size="lg" variant="outline" className="border-white text-white hover:bg-gray-900">
            Upload Product
          </Button>
        </div>
        <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-black to-transparent" />
      </section>

      {/* Live Auctions Slider */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Live Auctions</h2>
            <Link href="/auctions" className="flex items-center text-gray-300 hover:text-white">
              View all <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          <div className="overflow-x-auto pb-4">
            <div className="flex gap-6 min-w-max">
              <AuctionCard
                image="/placeholder.svg?height=300&width=400"
                name="Vintage Film Camera"
                category="Electronics"
                currentBid="$320"
                timeLeft="4:32"
              />
              <AuctionCard
                image="/placeholder.svg?height=300&width=400"
                name="Limited Edition Sneakers"
                category="Fashion"
                currentBid="$175"
                timeLeft="2:45"
              />
              <AuctionCard
                image="/placeholder.svg?height=300&width=400"
                name="Abstract Painting"
                category="Art"
                currentBid="$550"
                timeLeft="7:12"
              />
              <AuctionCard
                image="/placeholder.svg?height=300&width=400"
                name="Rare Vinyl Record"
                category="Collectibles"
                currentBid="$95"
                timeLeft="1:18"
              />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4 bg-gray-950">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="bg-gray-800 p-4 rounded-full mb-6">
                <Upload className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">Upload</h3>
              <p className="text-gray-400">List your item with photos and set your starting price in minutes.</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="bg-gray-800 p-4 rounded-full mb-6">
                <Clock className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">10-Minute Bidding</h3>
              <p className="text-gray-400">Each auction lasts exactly 10 minutes. Fast-paced and exciting.</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="bg-gray-800 p-4 rounded-full mb-6">
                <Award className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">Win & Collect</h3>
              <p className="text-gray-400">Highest bidder wins. Secure payment and shipping handled for you.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold mb-8">Browse Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <CategoryCard name="Electronics" count={42} image="/placeholder.svg?height=200&width=300" />
            <CategoryCard name="Fashion" count={38} image="/placeholder.svg?height=200&width=300" />
            <CategoryCard name="Art" count={24} image="/placeholder.svg?height=200&width=300" />
            <CategoryCard name="Collectibles" count={56} image="/placeholder.svg?height=200&width=300" />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-gray-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-2xl font-bold">10M</h2>
          </div>
          <div className="flex gap-6 text-sm text-gray-400">
            <Link href="/about" className="hover:text-white">
              About
            </Link>
            <Link href="/faq" className="hover:text-white">
              FAQ
            </Link>
            <Link href="/contact" className="hover:text-white">
              Contact
            </Link>
            <Link href="/socials" className="hover:text-white">
              Socials
            </Link>
          </div>
          <Button variant="ghost" size="icon" className="mt-4 md:mt-0">
            <Moon className="h-5 w-5" />
            <span className="sr-only">Toggle dark mode</span>
          </Button>
        </div>
      </footer>
    </div>
  )
}
