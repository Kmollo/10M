"use client"

import { useState } from "react"
import { Plus, Package, Clock, CheckCircle, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import DashboardSidebar from "@/components/dashboard-sidebar"
import ProductForm from "@/components/product-form"
import ProductsTable from "@/components/products-table"

// Mock data for demonstration
const mockProducts = {
  pending: [
    {
      id: 1,
      title: "Vintage Film Camera",
      category: "Electronics",
      startingPrice: 250,
      scheduledDate: "2024-01-15",
      scheduledTime: "14:00",
      image: "/placeholder.svg?height=100&width=100",
      status: "pending",
    },
    {
      id: 2,
      title: "Limited Edition Sneakers",
      category: "Fashion",
      startingPrice: 150,
      scheduledDate: "2024-01-16",
      scheduledTime: "16:30",
      image: "/placeholder.svg?height=100&width=100",
      status: "pending",
    },
  ],
  active: [
    {
      id: 3,
      title: "Abstract Painting",
      category: "Art",
      startingPrice: 400,
      currentBid: 550,
      timeLeft: "7:32",
      bids: 12,
      image: "/placeholder.svg?height=100&width=100",
      status: "active",
    },
    {
      id: 4,
      title: "Rare Vinyl Record",
      category: "Collectibles",
      startingPrice: 75,
      currentBid: 95,
      timeLeft: "2:18",
      bids: 8,
      image: "/placeholder.svg?height=100&width=100",
      status: "active",
    },
  ],
  completed: [
    {
      id: 5,
      title: "Designer Watch",
      category: "Fashion",
      startingPrice: 300,
      finalBid: 485,
      soldDate: "2024-01-10",
      bids: 15,
      image: "/placeholder.svg?height=100&width=100",
      status: "sold",
    },
    {
      id: 6,
      title: "Gaming Console",
      category: "Electronics",
      startingPrice: 200,
      finalBid: 0,
      soldDate: "2024-01-08",
      bids: 0,
      image: "/placeholder.svg?height=100&width=100",
      status: "unsold",
    },
  ],
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="flex">
        <DashboardSidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        <main className="flex-1 p-6">
          {activeTab === "overview" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">Dashboard Overview</h1>
                <p className="text-gray-400">Manage your auctions and track performance</p>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-400">Pending Auctions</CardTitle>
                    <Clock className="h-4 w-4 text-amber-400" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-white">{mockProducts.pending.length}</div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-400">Active Auctions</CardTitle>
                    <Package className="h-4 w-4 text-green-400" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-white">{mockProducts.active.length}</div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-400">Total Sales</CardTitle>
                    <CheckCircle className="h-4 w-4 text-blue-400" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-white">$485</div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-400">Success Rate</CardTitle>
                    <XCircle className="h-4 w-4 text-purple-400" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-white">50%</div>
                  </CardContent>
                </Card>
              </div>

              {/* Quick Actions */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Quick Actions</CardTitle>
                  <CardDescription className="text-gray-400">Get started with your next auction</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4">
                    <Button onClick={() => setActiveTab("upload")} className="bg-white text-black hover:bg-gray-200">
                      <Plus className="mr-2 h-4 w-4" />
                      Upload New Product
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setActiveTab("products")}
                      className="border-gray-600 text-white hover:bg-gray-800"
                    >
                      View All Products
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "upload" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">Upload Product</h1>
                <p className="text-gray-400">Create a new auction for your item</p>
              </div>
              <ProductForm />
            </div>
          )}

          {activeTab === "products" && (
            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">My Products</h1>
                <p className="text-gray-400">Manage all your auction listings</p>
              </div>

              <Tabs defaultValue="pending" className="w-full">
                <TabsList className="grid w-full grid-cols-3 bg-gray-900">
                  <TabsTrigger value="pending" className="data-[state=active]:bg-gray-800">
                    Pending ({mockProducts.pending.length})
                  </TabsTrigger>
                  <TabsTrigger value="active" className="data-[state=active]:bg-gray-800">
                    Active ({mockProducts.active.length})
                  </TabsTrigger>
                  <TabsTrigger value="completed" className="data-[state=active]:bg-gray-800">
                    Completed ({mockProducts.completed.length})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="pending" className="mt-6">
                  <ProductsTable products={mockProducts.pending} type="pending" />
                </TabsContent>

                <TabsContent value="active" className="mt-6">
                  <ProductsTable products={mockProducts.active} type="active" />
                </TabsContent>

                <TabsContent value="completed" className="mt-6">
                  <ProductsTable products={mockProducts.completed} type="completed" />
                </TabsContent>
              </Tabs>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
