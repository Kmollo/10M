import Image from "next/image"
import { Edit, Trash2, Eye, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Product {
  id: number
  title: string
  category: string
  startingPrice: number
  image: string
  status: string
  scheduledDate?: string
  scheduledTime?: string
  currentBid?: number
  timeLeft?: string
  bids?: number
  finalBid?: number
  soldDate?: string
}

interface ProductsTableProps {
  products: Product[]
  type: "pending" | "active" | "completed"
}

export default function ProductsTable({ products, type }: ProductsTableProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="secondary" className="bg-amber-900 text-amber-200">
            Pending
          </Badge>
        )
      case "active":
        return (
          <Badge variant="secondary" className="bg-green-900 text-green-200">
            Live
          </Badge>
        )
      case "sold":
        return (
          <Badge variant="secondary" className="bg-blue-900 text-blue-200">
            Sold
          </Badge>
        )
      case "unsold":
        return (
          <Badge variant="secondary" className="bg-red-900 text-red-200">
            Unsold
          </Badge>
        )
      default:
        return <Badge variant="secondary">Unknown</Badge>
    }
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-12 text-gray-400">
        <p>No {type} auctions found.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {products.map((product) => (
        <div key={product.id} className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <div className="flex items-center gap-4">
            <div className="relative w-16 h-16 rounded-lg overflow-hidden">
              <Image src={product.image || "/placeholder.svg"} alt={product.title} fill className="object-cover" />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-medium text-white truncate">{product.title}</h3>
                {getStatusBadge(product.status)}
              </div>
              <p className="text-sm text-gray-400">{product.category}</p>

              {type === "pending" && (
                <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
                  <span>
                    Scheduled: {product.scheduledDate} at {product.scheduledTime}
                  </span>
                  <span>Starting: ${product.startingPrice}</span>
                </div>
              )}

              {type === "active" && (
                <div className="flex items-center gap-4 mt-2 text-sm">
                  <span className="text-green-400">Current: ${product.currentBid}</span>
                  <span className="text-amber-400 flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {product.timeLeft}
                  </span>
                  <span className="text-gray-400">{product.bids} bids</span>
                </div>
              )}

              {type === "completed" && (
                <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
                  <span>Starting: ${product.startingPrice}</span>
                  {product.finalBid && product.finalBid > 0 ? (
                    <span className="text-green-400">Final: ${product.finalBid}</span>
                  ) : (
                    <span className="text-red-400">No bids</span>
                  )}
                  <span>Ended: {product.soldDate}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              {type === "pending" && (
                <>
                  <Button size="sm" variant="outline" className="border-gray-600 text-white hover:bg-gray-800">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="border-red-600 text-red-400 hover:bg-red-900">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </>
              )}

              {type === "active" && (
                <Button size="sm" variant="outline" className="border-gray-600 text-white hover:bg-gray-800">
                  <Eye className="h-4 w-4" />
                </Button>
              )}

              {type === "completed" && (
                <Button size="sm" variant="outline" className="border-gray-600 text-white hover:bg-gray-800">
                  <Eye className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
