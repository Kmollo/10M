import Image from "next/image"
import Link from "next/link"

interface CategoryCardProps {
  name: string
  count: number
  image: string
}

export default function CategoryCard({ name, count, image }: CategoryCardProps) {
  return (
    <Link href={`/category/${name.toLowerCase()}`}>
      <div className="relative h-40 rounded-lg overflow-hidden group">
        <Image
          src={image || "/placeholder.svg"}
          alt={name}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
        <div className="absolute bottom-0 left-0 p-4">
          <h3 className="font-bold text-lg">{name}</h3>
          <p className="text-sm text-gray-300">{count} auctions</p>
        </div>
      </div>
    </Link>
  )
}
