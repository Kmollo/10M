"use client"

import { useState } from "react"
import Image from "next/image"
import { Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface AuctionCardProps {
  image: string
  name: string
  category: string
  currentBid: string
  timeLeft: string
}

export default function AuctionCard({ image, name, category, currentBid, timeLeft }: AuctionCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className="relative bg-gray-900 rounded-lg overflow-hidden w-72 transition-all duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-48 w-full">
        <Image src={image || "/placeholder.svg"} alt={name} fill className="object-cover" />
        <div
          className={cn(
            "absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center transition-opacity duration-300",
            isHovered ? "opacity-100" : "opacity-0",
          )}
        >
          <Button className="bg-white text-black hover:bg-gray-200">Join Auction</Button>
        </div>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="font-medium text-lg">{name}</h3>
            <span className="text-xs px-2 py-1 bg-gray-800 rounded-full">{category}</span>
          </div>
        </div>
        <div className="flex justify-between items-center mt-4">
          <div>
            <p className="text-xs text-gray-400">Current Bid</p>
            <p className="font-bold">{currentBid}</p>
          </div>
          <div className="flex items-center text-amber-400">
            <Clock className="h-3 w-3 mr-1" />
            <span className="text-sm">{timeLeft}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
