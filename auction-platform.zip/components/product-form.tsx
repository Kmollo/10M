"use client"

import type React from "react"
import { useState } from "react"
import { Upload, Calendar, Clock, DollarSign } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

interface FormData {
  title: string
  description: string
  category: string
  startingPrice: string
  scheduledDate: string
  scheduledTime: string
  image: File | null
}

export default function ProductForm() {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState<FormData>({
    title: "",
    description: "",
    category: "",
    startingPrice: "",
    scheduledDate: "",
    scheduledTime: "",
    image: null,
  })

  const handleChange = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setFormData((prev) => ({ ...prev, image: file }))
    }
  }

  const validateForm = () => {
    const errors: string[] = []

    if (!formData.title.trim()) errors.push("Product title is required")
    if (!formData.description.trim()) errors.push("Description is required")
    if (!formData.category) errors.push("Category is required")
    if (!formData.startingPrice || Number.parseFloat(formData.startingPrice) <= 0)
      errors.push("Valid starting price is required")
    if (!formData.scheduledDate) errors.push("Auction date is required")
    if (!formData.scheduledTime) errors.push("Auction time is required")
    if (!formData.image) errors.push("Product image is required")

    return errors
  }

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      category: "",
      startingPrice: "",
      scheduledDate: "",
      scheduledTime: "",
      image: null,
    })
    // Reset file input
    const fileInput = document.getElementById("image") as HTMLInputElement
    if (fileInput) fileInput.value = ""
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const errors = validateForm()
    if (errors.length > 0) {
      toast({
        title: "Validation Error",
        description: errors[0],
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Success toast
      toast({
        title: "Auction Scheduled Successfully!",
        description: `"${formData.title}" has been scheduled for ${formData.scheduledDate} at ${formData.scheduledTime}`,
      })

      // Reset form after successful submission
      resetForm()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to schedule auction. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSaveDraft = () => {
    toast({
      title: "Draft Saved",
      description: "Your product has been saved as a draft.",
    })
  }

  return (
    <Card className="bg-gray-900 border-gray-800 max-w-2xl">
      <CardHeader>
        <CardTitle className="text-white">Product Details</CardTitle>
        <CardDescription className="text-gray-400">
          Fill in the information about your item to create an auction
        </CardDescription>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Image Upload Section */}
          <FormSection label="Product Image">
            <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center hover:border-gray-500 transition-colors">
              <input id="image" type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              <label htmlFor="image" className="cursor-pointer">
                <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-400">
                  {formData.image ? (
                    <span className="text-white font-medium">{formData.image.name}</span>
                  ) : (
                    "Click to upload or drag and drop"
                  )}
                </p>
                <p className="text-sm text-gray-500 mt-2">PNG, JPG, GIF up to 10MB</p>
              </label>
            </div>
          </FormSection>

          {/* Basic Information */}
          <FormSection label="Product Title">
            <Input
              id="title"
              placeholder="Enter product title"
              value={formData.title}
              onChange={(e) => handleChange("title", e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
              required
            />
          </FormSection>

          <FormSection label="Description">
            <Textarea
              id="description"
              placeholder="Describe your item..."
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              className="bg-gray-800 border-gray-700 text-white min-h-[100px]"
              required
            />
          </FormSection>

          {/* Category and Price */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormSection label="Category">
              <Select value={formData.category} onValueChange={(value) => handleChange("category", value)} required>
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="electronics">Electronics</SelectItem>
                  <SelectItem value="fashion">Fashion</SelectItem>
                  <SelectItem value="art">Art</SelectItem>
                  <SelectItem value="collectibles">Collectibles</SelectItem>
                  <SelectItem value="home">Home & Garden</SelectItem>
                  <SelectItem value="sports">Sports</SelectItem>
                </SelectContent>
              </Select>
            </FormSection>

            <FormSection label="Starting Price">
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="startingPrice"
                  type="number"
                  step="0.01"
                  min="0.01"
                  placeholder="0.00"
                  value={formData.startingPrice}
                  onChange={(e) => handleChange("startingPrice", e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white pl-10"
                  required
                />
              </div>
            </FormSection>
          </div>

          {/* Scheduling */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormSection label="Auction Date">
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="scheduledDate"
                  type="date"
                  value={formData.scheduledDate}
                  onChange={(e) => handleChange("scheduledDate", e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white pl-10"
                  min={new Date().toISOString().split("T")[0]}
                  required
                />
              </div>
            </FormSection>

            <FormSection label="Auction Time">
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="scheduledTime"
                  type="time"
                  value={formData.scheduledTime}
                  onChange={(e) => handleChange("scheduledTime", e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white pl-10"
                  required
                />
              </div>
            </FormSection>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4">
            <Button type="submit" className="bg-white text-black hover:bg-gray-200" disabled={isSubmitting}>
              {isSubmitting ? "Scheduling..." : "Schedule Auction"}
            </Button>
            <Button
              type="button"
              variant="outline"
              className="border-gray-600 text-white hover:bg-gray-800"
              onClick={handleSaveDraft}
              disabled={isSubmitting}
            >
              Save as Draft
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

// Helper component for form sections
function FormSection({
  label,
  children,
}: {
  label: string
  children: React.ReactNode
}) {
  return (
    <div className="space-y-2">
      <Label htmlFor={label.toLowerCase().replace(/\s+/g, "-")} className="text-white">
        {label}
      </Label>
      {children}
    </div>
  )
}
